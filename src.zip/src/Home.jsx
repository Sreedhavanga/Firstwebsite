import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const Home = () => {
  const sliderImages = [
    "/img1.jpg",
    "/img2.jpg",
    "/img3.jpg",
  ];

  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
  };

  return (
    <div id="home" style={{ margin: "20px" }}>
      <Slider {...sliderSettings} >
        {sliderImages.map((image, index) => (
          <div key={index} style={{  }}>
            <img
              src={image}
              alt={`Slide ${index + 1}`}
              style={{ height: '700px',width: "1000px", borderRadius: "10px",display: 'block',  // Ensures the slider behaves like a block element
                margin: '0 auto' }}
            />
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default Home;
